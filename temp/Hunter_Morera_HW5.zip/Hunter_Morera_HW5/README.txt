Each folder holds the corresponding spreadsheet for that problem

As per Dr. Zheng I have not put any of the integer instructions in the reservations stations, this is because he told us we could assume that those instructions were handled by different hardware somewhere else in the system.

Also note that in my Tomasulo's algorithm I have my store reservation stations below my
load stations. This is because I added them to the sheet and brought this point to 
Dr. Zheng and thats when he changed the spreadsheet to include these stations.

My total cycles per algorithm is listed below:

Tamosulo's = 22 total cycles
Hardware Speculation = 25 total cycles
Hardware Speculation w/ multi-issue = 18 total cycles